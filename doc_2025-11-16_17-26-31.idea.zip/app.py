import os
from datetime import datetime, timedelta
import secrets
from uuid import uuid4

from flask import (
    Flask,
    request,
    jsonify,
    session,
    send_from_directory,
    render_template
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

#############################
#  CONFIGURATION
#############################

app = Flask(__name__, template_folder="templates")

# секретный ключ (для сессий)
app.secret_key = "super_secret_key_change_me"

# MySQL settings
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:root@localhost:3306/rosatom"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# uploads
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# allowed file extensions
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

db = SQLAlchemy(app)

#############################
#  HELPERS
#############################

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def save_upload(file):
    """Сохраняет файл в /uploads и возвращает URL"""
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filename = f"{uuid4().hex}_{filename}"
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(filepath)
        return f"/uploads/{filename}"
    return None


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


def get_current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return User.query.get(user_id)


def login_required(f):
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        if not get_current_user():
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)

    return decorated


def admin_required(f):
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user()
        if not user or user.role != "admin":
            return jsonify({"error": "Admin access required"}), 403
        return f(*args, **kwargs)

    return decorated

####################################
#  DATABASE MODELS
####################################

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    first_name = db.Column(db.String(255))
    last_name = db.Column(db.String(255))

    role = db.Column(db.String(20), default="user")  # user / admin

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # relation → one user can manage only one organization
    organization = db.relationship("Organization", back_populates="creator", uselist=False)

    def set_password(self, pwd):
        self.password_hash = generate_password_hash(pwd)

    def check_password(self, pwd):
        return check_password_hash(self.password_hash, pwd)


class City(db.Model):
    __tablename__ = "cities"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    region = db.Column(db.String(255))
    lat = db.Column(db.Float)
    lon = db.Column(db.Float)

    organizations = db.relationship("Organization", back_populates="city")


class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    slug = db.Column(db.String(255), unique=True)

    organizations = db.relationship("Organization", back_populates="category")


class Organization(db.Model):
    __tablename__ = "organizations"

    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(255), nullable=False)

    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    category = db.relationship("Category", back_populates="organizations")

    city_id = db.Column(db.Integer, db.ForeignKey("cities.id"), nullable=False)
    city = db.relationship("City", back_populates="organizations")

    short_description = db.Column(db.Text, nullable=False)
    volunteer_description = db.Column(db.Text)

    phone = db.Column(db.String(255))
    address = db.Column(db.String(255))

    lat = db.Column(db.Float)
    lon = db.Column(db.Float)

    website_url = db.Column(db.String(255))
    logo_url = db.Column(db.String(255))   # uploaded file

    created_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    creator = db.relationship("User", back_populates="organization")

    status = db.Column(db.String(20), default="pending")  # pending / approved / rejected
    admin_comment = db.Column(db.Text)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    social_links = db.relationship("SocialLink", back_populates="organization")


class SocialLink(db.Model):
    __tablename__ = "social_links"

    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey("organizations.id"))

    type = db.Column(db.String(50))   # vk / telegram / ok / rutube / dzen / other
    url = db.Column(db.String(255))

    organization = db.relationship("Organization", back_populates="social_links")


class PasswordResetToken(db.Model):
    __tablename__ = "password_reset_tokens"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    token = db.Column(db.String(255), unique=True)
    expires_at = db.Column(db.DateTime)
    used = db.Column(db.Boolean, default=False)

    user = db.relationship("User")

####################################
#  REGISTER
####################################
@app.route("/api/auth/register", methods=["POST"])
def api_register():
    data = request.json or {}

    email = (data.get("email") or "").strip().lower()
    password = data.get("password")
    first_name = data.get("first_name")
    last_name = data.get("last_name")

    # Validation
    if not email or not password:
        return jsonify({"error": "Email и пароль обязательны"}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Пользователь уже существует"}), 400

    user = User(
        email=email,
        first_name=first_name,
        last_name=last_name
    )
    user.set_password(password)

    db.session.add(user)
    db.session.commit()

    session["user_id"] = user.id
    session["role"] = user.role

    return jsonify({"message": "Регистрация успешна"})

####################################
#  LOGIN
####################################
@app.route("/api/auth/login", methods=["POST"])
def api_login():
    data = request.json or {}

    email = (data.get("email") or "").strip().lower()
    password = data.get("password")

    user = User.query.filter_by(email=email).first()

    if not user or not user.check_password(password):
        return jsonify({"error": "Неверный email или пароль"}), 400

    session["user_id"] = user.id
    session["role"] = user.role

    return jsonify({"message": "Авторизация успешна"})


####################################
#  LOGOUT
####################################
@app.route("/api/auth/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"message": "Вы вышли из аккаунта"})


####################################
#  WHO AM I
####################################
@app.route("/api/auth/me", methods=["GET"])
def api_me():
    user = get_current_user()
    if not user:
        return jsonify({"user": None})

    return jsonify({
        "id": user.id,
        "email": user.email,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "role": user.role
    })

####################################
#  PASSWORD RESET - REQUEST TOKEN
####################################
@app.route("/api/auth/password/forgot", methods=["POST"])
def api_password_forgot():
    data = request.json or {}
    email = (data.get("email") or "").strip().lower()

    user = User.query.filter_by(email=email).first()
    if not user:
        # не палим существование почты
        return jsonify({"message": "Если email существует – письмо отправлено"})

    token = secrets.token_urlsafe(32)

    prt = PasswordResetToken(
        user_id=user.id,
        token=token,
        expires_at=datetime.utcnow() + timedelta(hours=1),
        used=False
    )

    db.session.add(prt)
    db.session.commit()

    # при реальной отправке → отправить письмо
    return jsonify({
        "message": "Токен создан",
        "token": token      # ← оставляем для тестов
    })

####################################
#  PASSWORD RESET - APPLY
####################################
@app.route("/api/auth/password/reset", methods=["POST"])
def api_password_reset():
    data = request.json or {}

    token = data.get("token")
    new_password = data.get("password")

    if not token or not new_password:
        return jsonify({"error": "Требуется токен и новый пароль"}), 400

    prt = PasswordResetToken.query.filter_by(
        token=token,
        used=False
    ).first()

    if not prt:
        return jsonify({"error": "Неверный или использованный токен"}), 400

    if prt.expires_at < datetime.utcnow():
        return jsonify({"error": "Срок действия токена истёк"}), 400

    user = prt.user
    user.set_password(new_password)
    prt.used = True

    db.session.commit()

    return jsonify({"message": "Пароль успешно изменён"})

####################################
#  FRONTEND ENTRY
####################################
@app.route("/")
def index_page():
    # одна страница, всё SPA/JS живёт внутри index.html
    return render_template("index.html")

####################################
#  DICTIONARIES: CITIES & CATEGORIES
####################################
@app.route("/api/cities", methods=["GET"])
def api_cities():
    cities = City.query.order_by(City.name.asc()).all()
    return jsonify([
        {
            "id": c.id,
            "name": c.name,
            "region": c.region,
            "lat": c.lat,
            "lon": c.lon
        }
        for c in cities
    ])


@app.route("/api/categories", methods=["GET"])
def api_categories():
    categories = Category.query.order_by(Category.name.asc()).all()
    return jsonify([
        {
            "id": cat.id,
            "name": cat.name,
            "slug": cat.slug
        }
        for cat in categories
    ])

####################################
#  ORGANIZATION → DICT HELPER
####################################
def organization_to_dict(org: Organization):
    return {
        "id": org.id,
        "name": org.name,

        "city_id": org.city_id,
        "city_name": org.city.name if org.city else None,
        "city_region": org.city.region if org.city else None,

        "category_id": org.category_id,
        "category_name": org.category.name if org.category else None,
        "category_slug": org.category.slug if org.category else None,

        "short_description": org.short_description,
        "volunteer_description": org.volunteer_description,

        "phone": org.phone,
        "address": org.address,

        "coordinates": {
            "lat": org.lat,
            "lon": org.lon
        },

        "website_url": org.website_url,
        "logo_url": org.logo_url,

        "status": org.status,
        "admin_comment": org.admin_comment,

        "created_by_user_id": org.created_by,
        "created_at": org.created_at.isoformat() if org.created_at else None,
        "updated_at": org.updated_at.isoformat() if org.updated_at else None,

        "social_links": [
            {
                "id": sl.id,
                "type": sl.type,
                "url": sl.url
            }
            for sl in org.social_links
        ]
    }

####################################
#  GET ORGANIZATIONS (LIST + FILTERS)
####################################
@app.route("/api/organizations", methods=["GET"])
def api_organizations_list():
    city_id = request.args.get("city_id", type=int)
    category_id = request.args.get("category_id", type=int)
    query = request.args.get("query", type=str)
    mine = request.args.get("mine", type=str) == "true"

    user = get_current_user()
    q = Organization.query

    if mine:
        if not user:
            return jsonify({"error": "Требуется авторизация"}), 401
        q = q.filter(Organization.created_by == user.id)
    else:
        # для публичного API показываем только approved
        q = q.filter(Organization.status == "approved")

    if city_id:
        q = q.filter(Organization.city_id == city_id)

    if category_id:
        q = q.filter(Organization.category_id == category_id)

    if query:
        like = f"%{query}%"
        q = q.filter(Organization.name.ilike(like))

    orgs = q.order_by(Organization.name.asc()).all()
    return jsonify([organization_to_dict(o) for o in orgs])


####################################
#  GET ORGANIZATION DETAIL
####################################
@app.route("/api/organizations/<int:org_id>", methods=["GET"])
def api_organization_detail(org_id):
    org = Organization.query.get_or_404(org_id)
    user = get_current_user()

    if org.status != "approved":
        # только создатель или админ
        if not user or (user.id != org.created_by and user.role != "admin"):
            return jsonify({"error": "Организация недоступна"}), 403

    return jsonify(organization_to_dict(org))


####################################
#  CREATE ORGANIZATION
####################################
@app.route("/api/organizations", methods=["POST"])
@login_required
def api_organization_create():
    user = get_current_user()

    # одна НКО на пользователя
    if user.organization:
        return jsonify({"error": "К вашему аккаунту уже привязана НКО"}), 400

    # поддерживаем и JSON, и form-data
    if request.is_json:
        data = request.json or {}
    else:
        data = request.form.to_dict()

    name = (data.get("name") or "").strip()
    category_id = data.get("category_id")
    city_id = data.get("city_id")
    short_description = (data.get("short_description") or "").strip()

    if not name or not category_id or not city_id or not short_description:
        return jsonify({"error": "name, category_id, city_id, short_description обязательны"}), 400

    try:
        category_id = int(category_id)
        city_id = int(city_id)
    except ValueError:
        return jsonify({"error": "category_id и city_id должны быть числами"}), 400

    org = Organization(
        name=name,
        category_id=category_id,
        city_id=city_id,
        short_description=short_description,
        volunteer_description=data.get("volunteer_description"),
        phone=data.get("phone"),
        address=data.get("address"),
        website_url=data.get("website_url"),
        created_by=user.id,
        status="pending"
    )

    # координаты
    lat = data.get("lat")
    lon = data.get("lon")
    if lat and lon:
        try:
            org.lat = float(lat)
            org.lon = float(lon)
        except ValueError:
            pass

    # логотип (если файл)
    if "logo" in request.files:
        logo_file = request.files["logo"]
        url = save_upload(logo_file)
        if url:
            org.logo_url = url
    else:
        # либо логотип как уже готовый URL
        logo_url = data.get("logo_url")
        if logo_url:
            org.logo_url = logo_url

    db.session.add(org)
    db.session.flush()  # нужен id для соцсетей

    # соцсети (если JSON)
    social_links = []
    if request.is_json:
        social_links = data.get("social_links") or []
    else:
        # можно поддержать простую форму вида social_vk, social_tg ...
        pass

    for sl in social_links:
        t = (sl.get("type") or "other").strip()
        u = (sl.get("url") or "").strip()
        if u:
            db.session.add(SocialLink(
                organization_id=org.id,
                type=t,
                url=u
            ))

    db.session.commit()

    return jsonify({
        "message": "Организация создана и отправлена на модерацию",
        "organization": organization_to_dict(org)
    })


####################################
#  UPDATE ORGANIZATION
####################################
@app.route("/api/organizations/<int:org_id>", methods=["PUT", "PATCH"])
@login_required
def api_organization_update(org_id):
    user = get_current_user()
    org = Organization.query.get_or_404(org_id)

    if user.role != "admin" and user.id != org.created_by:
        return jsonify({"error": "Недостаточно прав для редактирования"}), 403

    if request.is_json:
        data = request.json or {}
    else:
        data = request.form.to_dict()

    def set_if_in(field, cast=None):
        if field in data and data.get(field) is not None:
            value = data.get(field)
            if cast:
                try:
                    value = cast(value)
                except Exception:
                    return
            setattr(org, field, value)

    set_if_in("name")
    set_if_in("short_description")
    set_if_in("volunteer_description")
    set_if_in("phone")
    set_if_in("address")
    set_if_in("website_url")

    if "category_id" in data:
        try:
            org.category_id = int(data["category_id"])
        except ValueError:
            pass

    if "city_id" in data:
        try:
            org.city_id = int(data["city_id"])
        except ValueError:
            pass

    if "lat" in data and "lon" in data:
        try:
            org.lat = float(data["lat"])
            org.lon = float(data["lon"])
        except ValueError:
            pass

    # логотип
    if "logo" in request.files:
        logo_file = request.files["logo"]
        url = save_upload(logo_file)
        if url:
            org.logo_url = url
    elif "logo_url" in data:
        org.logo_url = data.get("logo_url")

    # соцсети целиком заменяем (если приходит массив social_links)
    if request.is_json and "social_links" in data:
        SocialLink.query.filter_by(organization_id=org.id).delete()
        for sl in data.get("social_links") or []:
            t = (sl.get("type") or "other").strip()
            u = (sl.get("url") or "").strip()
            if u:
                db.session.add(SocialLink(
                    organization_id=org.id,
                    type=t,
                    url=u
                ))

    db.session.commit()

    return jsonify({
        "message": "Организация обновлена",
        "organization": organization_to_dict(org)
    })

####################################
#  ADMIN: LIST ORGANIZATIONS
####################################
@app.route("/api/admin/organizations", methods=["GET"])
@admin_required
def api_admin_organizations():
    status = request.args.get("status")  # optional: pending/approved/rejected

    q = Organization.query

    if status:
        q = q.filter(Organization.status == status)

    orgs = q.order_by(Organization.created_at.desc()).all()
    return jsonify([organization_to_dict(o) for o in orgs])

####################################
#  ADMIN: APPROVE / REJECT
####################################
@app.route("/api/admin/organizations/<int:org_id>/approve", methods=["POST"])
@admin_required
def api_admin_approve(org_id):
    org = Organization.query.get_or_404(org_id)
    org.status = "approved"
    org.admin_comment = None
    db.session.commit()
    return jsonify({"message": "Организация одобрена", "organization": organization_to_dict(org)})


@app.route("/api/admin/organizations/<int:org_id>/reject", methods=["POST"])
@admin_required
def api_admin_reject(org_id):
    org = Organization.query.get_or_404(org_id)

    data = request.json or {}
    comment = data.get("admin_comment") or "Отклонено администратором"

    org.status = "rejected"
    org.admin_comment = comment

    db.session.commit()
    return jsonify({"message": "Организация отклонена", "organization": organization_to_dict(org)})


####################################
#  MAP API: POINTS FOR YANDEX MAP
####################################
@app.route("/api/map/points", methods=["GET"])
def api_map_points():
    """
    Возвращает список НКО для отображения на карте.
    Только approved организации.
    Фильтры такие же, как у /api/organizations:
    ?city_id=&category_id=&query=
    """
    city_id = request.args.get("city_id", type=int)
    category_id = request.args.get("category_id", type=int)
    query = request.args.get("query", type=str)

    q = Organization.query.filter(Organization.status == "approved")

    if city_id:
        q = q.filter(Organization.city_id == city_id)
    if category_id:
        q = q.filter(Organization.category_id == category_id)
    if query:
        like = f"%{query}%"
        q = q.filter(Organization.name.ilike(like))

    orgs = q.all()

    points = []
    for o in orgs:
        if o.lat is None or o.lon is None:
            # без координат на карту не выводим
            continue
        points.append({
            "id": o.id,
            "name": o.name,
            "city_id": o.city_id,
            "city_name": o.city.name if o.city else None,
            "category_id": o.category_id,
            "category_name": o.category.name if o.category else None,
            "short_description": o.short_description,
            "volunteer_description": o.volunteer_description,
            "address": o.address,
            "phone": o.phone,
            "website_url": o.website_url,
            "logo_url": o.logo_url,
            "coordinates": {
                "lat": o.lat,
                "lon": o.lon
            },
            "social_links": [
                {"type": sl.type, "url": sl.url}
                for sl in o.social_links
            ]
        })

    return jsonify(points)

####################################
#  PROFILE: GET / UPDATE / DELETE
####################################
@app.route("/api/profile", methods=["GET"])
@login_required
def api_profile_get():
    user = get_current_user()
    return jsonify({
        "id": user.id,
        "email": user.email,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "role": user.role,
        "created_at": user.created_at.isoformat() if user.created_at else None
    })


@app.route("/api/profile", methods=["PUT", "PATCH"])
@login_required
def api_profile_update():
    user = get_current_user()
    data = request.json or {}

    if "first_name" in data:
        user.first_name = data.get("first_name") or None
    if "last_name" in data:
        user.last_name = data.get("last_name") or None

    # смена пароля по желанию (старый + новый)
    old_password = data.get("old_password")
    new_password = data.get("new_password")
    if new_password:
        if not old_password or not user.check_password(old_password):
            return jsonify({"error": "Неверный текущий пароль"}), 400
        user.set_password(new_password)

    db.session.commit()
    return jsonify({"message": "Профиль обновлён"})


@app.route("/api/profile", methods=["DELETE"])
@login_required
def api_profile_delete():
    user = get_current_user()

    # на проде это обычно помечается флагом is_deleted,
    # здесь для простоты можно реально удалять
    # + удаляем привязанную НКО (если есть)
    if user.organization:
        SocialLink.query.filter_by(organization_id=user.organization.id).delete()
        db.session.delete(user.organization)

    db.session.delete(user)
    db.session.commit()
    session.clear()

    return jsonify({"message": "Аккаунт удалён"})

####################################
#  CLI: INIT DB & SEED DATA
####################################
@app.cli.command("init-db")
def init_db_command():
    """Создаёт все таблицы в базе данных."""
    db.create_all()
    print("Таблицы созданы.")


@app.cli.command("seed-data")
def seed_data_command():
    """Заполнение справочников (города, категории) и создание админа."""
    # базовые категории
    base_categories = [
        ("Социальная помощь", "social_help"),
        ("Экология", "ecology"),
        ("Культура и искусство", "culture"),
        ("Спорт и ЗОЖ", "sport"),
        ("Образование", "education"),
        ("Благотворительность", "charity"),
    ]
    for name, slug in base_categories:
        if not Category.query.filter_by(slug=slug).first():
            db.session.add(Category(name=name, slug=slug))

    # города Росатома из ТЗ
    rosatom_cities = [
        ("Ангарск", "Иркутская область"),
        ("Байкальск", "Иркутская область"),
        ("Балаково", "Саратовская область"),
        ("Билибино", "Чукотский АО"),
        ("Волгодонск", "Ростовская область"),
        ("Глазов", "Удмуртская Республика"),
        ("Десногорск", "Смоленская область"),
        ("Димитровград", "Ульяновская область"),
        ("Железногорск", "Красноярский край"),
        ("ЗАТО Заречный", "Пензенская область"),
        ("Заречный", "Свердловская область"),
        ("Зеленогорск", "Красноярский край"),
        ("Краснокаменск", "Забайкальский край"),
        ("Курчатов", "Курская область"),
        ("Лесной", "Свердловская область"),
        ("Неман", "Калининградская область"),
        ("Нововоронеж", "Воронежская область"),
        ("Новоуральск", "Свердловская область"),
        ("Обнинск", "Калужская область"),
        ("Озерск", "Челябинская область"),
        ("Певек", "Чукотский АО"),
        ("Полярные Зори", "Мурманская область"),
        ("Саров", "Нижегородская область"),
        ("Северск", "Томская область"),
        ("Снежинск", "Челябинская область"),
        ("Советск", "Калининградская область"),
        ("Сосновый Бор", "Ленинградская область"),
        ("Трехгорный", "Челябинская область"),
        ("Удомля", "Тверская область"),
        ("Усолье-Сибирское", "Иркутская область"),
        ("Электросталь", "Московская область"),
        ("Энергодар", "Запорожская область"),
    ]

    for name, region in rosatom_cities:
        if not City.query.filter_by(name=name, region=region).first():
            db.session.add(City(name=name, region=region))

    # админ
    if not User.query.filter_by(email="admin@example.com").first():
        admin = User(
            email="admin@example.com",
            first_name="Админ",
            last_name="Системы",
            role="admin",
        )
        admin.set_password("admin123")
        db.session.add(admin)

    db.session.commit()
    print("Справочники и админ созданы.")

####################################
#  MAIN ENTRY
####################################
if __name__ == "__main__":
    # на всякий случай создаём таблицы при первом запуске
    with app.app_context():
        db.create_all()
    app.run(debug=True)
