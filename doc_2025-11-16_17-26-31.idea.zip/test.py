'''import os
from datetime import datetime, timedelta
import secrets

from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    session,
    redirect,
    url_for
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# -------------------------
#  Конфигурация приложения
# -------------------------

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev_secret_key_change_me")

# Настройка подключения к MySQL
# ЗАМЕНИ user:password@host/dbname на свои реальные данные
app.config["SQLALCHEMY_DATABASE_URI"] = (
    os.environ.get(
        "DATABASE_URL",
        "mysql+pymysql://root:root@localhost:3306/test"
    )
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# -------------------------
#  Модели БД
# -------------------------

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    role = db.Column(db.String(20), default="user")  # 'user' или 'admin'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    organization = db.relationship("Organization", back_populates="creator", uselist=False)

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class City(db.Model):
    __tablename__ = "cities"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    region = db.Column(db.String(255))
    latitude = db.Column(db.Float)   # опционально, для центрирования карты
    longitude = db.Column(db.Float)  # опционально, для центрирования карты

    organizations = db.relationship("Organization", back_populates="city")


class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    slug = db.Column(db.String(255), unique=True)

    organizations = db.relationship("Organization", back_populates="category")

class Button(db.Model):
    __tablename__ = "buttons"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    color = db.Column(db.String(20), nullable=False)  # blue / green / red
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Organization(db.Model):
    __tablename__ = "organizations"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)

    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    category = db.relationship("Category", back_populates="organizations")

    city_id = db.Column(db.Integer, db.ForeignKey("cities.id"), nullable=False)
    city = db.relationship("City", back_populates="organizations")

    short_description = db.Column(db.Text, nullable=False)
    volunteer_description = db.Column(db.Text)  # функционал волонтеров

    phone = db.Column(db.String(50))
    address = db.Column(db.String(255))

    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)

    logo_url = db.Column(db.String(500))
    website_url = db.Column(db.String(500))

    created_by_user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    creator = db.relationship("User", back_populates="organization")

    status = db.Column(db.String(20), default="pending")  # pending / approved / rejected
    admin_comment = db.Column(db.Text)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    social_links = db.relationship("OrganizationSocialLink", back_populates="organization")


class OrganizationSocialLink(db.Model):
    __tablename__ = "organization_social_links"
    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey("organizations.id"))
    type = db.Column(db.String(50))  # vk / telegram / ok / rutube / dzen / other
    url = db.Column(db.String(500))

    organization = db.relationship("Organization", back_populates="social_links")


class PasswordResetToken(db.Model):
    __tablename__ = "password_reset_tokens"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    token = db.Column(db.String(255), unique=True, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)

    user = db.relationship("User")


# -------------------------
#  Вспомогательные функции
# -------------------------

def get_current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return User.query.get(user_id)


def login_required(f):
    from functools import wraps

    @wraps(f)
    def wrapper(*args, **kwargs):
        if not get_current_user():
            return jsonify({"error": "Требуется авторизация"}), 401
        return f(*args, **kwargs)

    return wrapper


def admin_required(f):
    from functools import wraps

    @wraps(f)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user or user.role != "admin":
            return jsonify({"error": "Требуются права администратора"}), 403
        return f(*args, **kwargs)

    return wrapper


def organization_to_dict(org: Organization):
    return {
        "id": org.id,
        "name": org.name,
        "category": org.category.name if org.category else None,
        "category_id": org.category_id,
        "city": org.city.name if org.city else None,
        "city_id": org.city_id,
        "short_description": org.short_description,
        "volunteer_description": org.volunteer_description,
        "phone": org.phone,
        "address": org.address,
        "latitude": org.latitude,
        "longitude": org.longitude,
        "logo_url": org.logo_url,
        "website_url": org.website_url,
        "status": org.status,
        "admin_comment": org.admin_comment,
        "social_links": [
            {"type": s.type, "url": s.url} for s in org.social_links
        ],
    }


# -------------------------
#  Роуты фронта
# -------------------------

@app.route("/")
def index():
    # Единственная страница (SPA)
    return render_template("index.html", current_user=get_current_user())


# -------------------------
#  API: справочники
# -------------------------

@app.route("/api/cities", methods=["GET"])
def api_cities():
    cities = City.query.order_by(City.name).all()
    return jsonify([
        {
            "id": c.id,
            "name": c.name,
            "region": c.region,
            "latitude": c.latitude,
            "longitude": c.longitude,
        } for c in cities
    ])


@app.route("/api/categories", methods=["GET"])
def api_categories():
    categories = Category.query.order_by(Category.name).all()
    return jsonify([
        {
            "id": cat.id,
            "name": cat.name,
            "slug": cat.slug,
        } for cat in categories
    ])

@app.route("/api/buttons", methods=["GET"])
def api_buttons():
    buttons = Button.query.order_by(Button.id).all()
    return jsonify([
        {
            "id": b.id,
            "name": b.name,
            "color": b.color
        } for b in buttons
    ])


@app.route("/api/button/<int:button_id>", methods=["GET"])
def api_button_detail(button_id):
    b = Button.query.get_or_404(button_id)
    return jsonify({
        "id": b.id,
        "name": b.name,
        "description": b.description,
        "color": b.color,
        "created_at": b.created_at.isoformat()
    })

# -------------------------
#  API: работа с НКО
# -------------------------

@app.route("/api/organizations", methods=["GET"])
def api_organizations():
    """
    GET /api/organizations?city_id=&category_id=&query=
    Возвращает только approved для обычных пользователей.
    """
    city_id = request.args.get("city_id", type=int)
    category_id = request.args.get("category_id", type=int)
    query = request.args.get("query", type=str)
    mine = request.args.get("mine", type=str) == "true"

    user = get_current_user()

    q = Organization.query

    if mine:
        if not user:
            return jsonify({"error": "Требуется авторизация"}), 401
        q = q.filter(Organization.created_by_user_id == user.id)
    else:
        # Показываем только одобренные
        q = q.filter(Organization.status == "approved")


    if city_id:
        q = q.filter(Organization.city_id == city_id)

    if category_id:
        q = q.filter(Organization.category_id == category_id)

    if query:
        like = f"%{query}%"
        q = q.filter(Organization.name.ilike(like))

    orgs = q.order_by(Organization.name).all()
    return jsonify([organization_to_dict(o) for o in orgs])


@app.route("/api/organizations/<int:org_id>", methods=["GET"])
def api_organization_detail(org_id):
    org = Organization.query.get_or_404(org_id)
    # Если организация не одобрена — показывать только владельцу или админу
    user = get_current_user()
    if org.status != "approved":
        if not user or (user.id != org.created_by_user_id and user.role != "admin"):
            return jsonify({"error": "Организация не доступна"}), 403
    return jsonify(organization_to_dict(org))


@app.route("/api/organizations", methods=["POST"])
@login_required
def api_organization_create():
    """
    Создание НКО (одна НКО на пользователя).
    Статус: pending (ждет модерации).
    """
    user = get_current_user()

    if user.organization:
        return jsonify({"error": "К аккаунту уже привязана НКО"}), 400

    data = request.json or {}

    required_fields = ["name", "category_id", "city_id", "short_description"]
    for f in required_fields:
        if not data.get(f):
            return jsonify({"error": f"Поле {f} обязательно"}), 400

    org = Organization(
        name=data["name"],
        category_id=data["category_id"],
        city_id=data["city_id"],
        short_description=data["short_description"],
        volunteer_description=data.get("volunteer_description"),
        phone=data.get("phone"),
        address=data.get("address"),
        latitude=data.get("latitude"),
        longitude=data.get("longitude"),
        logo_url=data.get("logo_url"),
        website_url=data.get("website_url"),
        created_by_user_id=user.id,
        status="pending",
    )

    db.session.add(org)
    db.session.flush()  # чтобы появился org.id

    social_links = data.get("social_links") or []
    for s in social_links:
        sl = OrganizationSocialLink(
            organization_id=org.id,
            type=s.get("type", "other"),
            url=s.get("url"),
        )
        db.session.add(sl)

    db.session.commit()
    return jsonify({"message": "Организация создана и отправлена на модерацию", "id": org.id})


@app.route("/api/organizations/<int:org_id>", methods=["PUT"])
@login_required
def api_organization_update(org_id):
    """
    Обновление данных НКО владельцем.
    Можно решить: после каждого изменения снова отправлять в pending,
    но здесь для простоты не меняем статус.
    """
    user = get_current_user()
    org = Organization.query.get_or_404(org_id)

    if org.created_by_user_id != user.id and user.role != "admin":
        return jsonify({"error": "Нет прав редактировать эту организацию"}), 403

    data = request.json or {}

    for field in [
        "name", "category_id", "city_id",
        "short_description", "volunteer_description",
        "phone", "address", "latitude", "longitude",
        "logo_url", "website_url"
    ]:
        if field in data:
            setattr(org, field, data[field])

    # Обновим соцсети целиком
    if "social_links" in data:
        # удаляем старые
        OrganizationSocialLink.query.filter_by(organization_id=org.id).delete()
        for s in data["social_links"] or []:
            sl = OrganizationSocialLink(
                organization_id=org.id,
                type=s.get("type", "other"),
                url=s.get("url"),
            )
            db.session.add(sl)

    db.session.commit()
    return jsonify({"message": "Организация обновлена"})


# -------------------------
#  API: модерация (админ)
# -------------------------


@app.route("/api/admin/organizations", methods=["GET"])
@admin_required
def api_admin_organizations():
    """
    GET /api/admin/organizations?status=pending
    """
    status = request.args.get("status")
    q = Organization.query
    if status:
        q = q.filter(Organization.status == status)
    orgs = q.order_by(Organization.created_at.desc()).all()
    return jsonify([organization_to_dict(o) for o in orgs])


@app.route("/api/admin/organizations/<int:org_id>/approve", methods=["POST"])
@admin_required
def api_admin_approve(org_id):
    org = Organization.query.get_or_404(org_id)
    org.status = "approved"
    org.admin_comment = None
    db.session.commit()
    return jsonify({"message": "Организация одобрена"})


@app.route("/api/admin/organizations/<int:org_id>/reject", methods=["POST"])
@admin_required
def api_admin_reject(org_id):
    org = Organization.query.get_or_404(org_id)
    data = request.json or {}
    comment = data.get("admin_comment", "Отклонено администратором")
    org.status = "rejected"
    org.admin_comment = comment
    db.session.commit()
    return jsonify({"message": "Организация отклонена"})


# -------------------------
#  API: аутентификация
# -------------------------

@app.route("/api/auth/register", methods=["POST"])
def api_register():
    data = request.json or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password")
    first_name = data.get("first_name")
    last_name = data.get("last_name")

    if not email or not password:
        return jsonify({"error": "Email и пароль обязательны"}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Пользователь с таким email уже существует"}), 400

    user = User(
        email=email,
        first_name=first_name,
        last_name=last_name,
        role="user",
    )
    user.set_password(password)

    db.session.add(user)
    db.session.commit()

    session["user_id"] = user.id
    session["role"] = user.role

    return jsonify({"message": "Регистрация успешна"})


@app.route("/api/auth/login", methods=["POST"])
def api_login():
    data = request.json or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password")

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return jsonify({"error": "Неверный email или пароль"}), 400

    session["user_id"] = user.id
    session["role"] = user.role

    return jsonify({"message": "Авторизация успешна"})


@app.route("/api/auth/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"message": "Вы вышли из аккаунта"})


@app.route("/api/auth/me", methods=["GET"])
def api_me():
    user = get_current_user()
    if not user:
        return jsonify({"user": None})
    return jsonify({
        "id": user.id,
        "email": user.email,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "role": user.role,
    })


# -------------------------
#  API: восстановление пароля
# (почтовую отправку можно прикрутить позже)
# -------------------------

@app.route("/api/auth/password/forgot", methods=["POST"])
def api_password_forgot():
    data = request.json or {}
    email = data.get("email", "").strip().lower()

    user = User.query.filter_by(email=email).first()
    if not user:
        # Не палим, что пользователя нет
        return jsonify({"message": "Если пользователь существует, ссылка будет отправлена"}), 200

    token = secrets.token_urlsafe(32)
    prt = PasswordResetToken(
        user_id=user.id,
        token=token,
        expires_at=datetime.utcnow() + timedelta(hours=1),
        used=False,
    )
    db.session.add(prt)
    db.session.commit()

    # Здесь должна быть отправка email с ссылкой вида:
    # https://your-site/reset-password?token=...
    # Для упрощения вернем токен в ответе (для тестирования)
    return jsonify({
        "message": "Токен для сброса пароля создан (в реале его нужно отправить по email)",
        "token": token
    })


@app.route("/api/auth/password/reset", methods=["POST"])
def api_password_reset():
    data = request.json or {}
    token = data.get("token")
    new_password = data.get("password")

    if not token or not new_password:
        return jsonify({"error": "Токен и новый пароль обязательны"}), 400

    prt = PasswordResetToken.query.filter_by(token=token, used=False).first()
    if not prt:
        return jsonify({"error": "Неверный или использованный токен"}), 400

    if prt.expires_at < datetime.utcnow():
        return jsonify({"error": "Срок действия токена истёк"}), 400

    user = prt.user
    user.set_password(new_password)
    prt.used = True

    db.session.commit()

    return jsonify({"message": "Пароль успешно изменен"})


# -------------------------
#  Инициализация БД
# -------------------------

@app.cli.command("init-db")
def init_db_command():
    """Создать таблицы в БД."""
    db.create_all()
    print("Таблицы созданы.")


@app.cli.command("seed-data")
def seed_data_command():
    """Начальное наполнение справочников (города и категории)."""
    # Простейшие категории
    base_categories = [
        ("Социальная помощь", "social_help"),
        ("Экология", "ecology"),
        ("Культура и искусство", "culture"),
        ("Спорт и ЗОЖ", "sport"),
        ("Образование", "education"),
        ("Благотворительность", "charity"),
    ]
    for name, slug in base_categories:
        if not Category.query.filter_by(slug=slug).first():
            db.session.add(Category(name=name, slug=slug))

    # Города Росатома из ТЗ (без координат, их можно потом добавить)
    cities = [
        ("Ангарск", "Иркутская область"),
        ("Байкальск", "Иркутская область"),
        ("Балаково", "Саратовская область"),
        ("Билибино", "Чукотский АО"),
        ("Волгодонск", "Ростовская область"),
        ("Глазов", "Удмуртская Республика"),
        ("Десногорск", "Смоленская область"),
        ("Димитровград", "Ульяновская область"),
        ("Железногорск", "Красноярский край"),
        ("ЗАТО Заречный", "Пензенская область"),
        ("Заречный", "Свердловская область"),
        ("Зеленогорск", "Красноярский край"),
        ("Краснокаменск", "Забайкальский край"),
        ("Курчатов", "Курская область"),
        ("Лесной", "Свердловская область"),
        ("Неман", "Калининградская область"),
        ("Нововоронеж", "Воронежская область"),
        ("Новоуральск", "Свердловская область"),
        ("Обнинск", "Калужская область"),
        ("Озерск", "Челябинская область"),
        ("Певек", "Чукотский АО"),
        ("Полярные Зори", "Мурманская область"),
        ("Саров", "Нижегородская область"),
        ("Северск", "Томская область"),
        ("Снежинск", "Челябинская область"),
        ("Советск", "Калининградская область"),
        ("Сосновый Бор", "Ленинградская область"),
        ("Трехгорный", "Челябинская область"),
        ("Удомля", "Тверская область"),
        ("Усолье-Сибирское", "Иркутская область"),
        ("Электросталь", "Московская область"),
        ("Энергодар", "Запорожская область"),
    ]

    for name, region in cities:
        if not City.query.filter_by(name=name, region=region).first():
            db.session.add(City(name=name, region=region))

    # Создадим одного админа
    if not User.query.filter_by(email="admin@example.com").first():
        admin = User(
            email="admin@example.com",
            first_name="Admin",
            last_name="Admin",
            role="admin",
        )
        admin.set_password("admin123")
        db.session.add(admin)

        # Тестовые кнопки
        if not Button.query.first():
            demo_buttons = [
                Button(
                    name="Синяя кнопка",
                    description="Это пример синей кнопки из базы данных.",
                    color="blue",
                ),
                Button(
                    name="Зелёная кнопка",
                    description="Эта зелёная кнопка тоже пришла из MySQL.",
                    color="green",
                ),
                Button(
                    name="Красная кнопка",
                    description="Красная кнопка — просто для демонстрации.",
                    color="red",
                ),
            ]
            db.session.add_all(demo_buttons)

        db.session.commit()
        print("Справочники, админ и кнопки созданы.")

        # Тестовые кнопки
        if not Button.query.first():
            demo_buttons = [
                Button(
                    name="Синяя кнопка",
                    description="Это пример синей кнопки из базы данных.",
                    color="blue",
                ),
                Button(
                    name="Зелёная кнопка",
                    description="Эта зелёная кнопка тоже пришла из MySQL.",
                    color="green",
                ),
                Button(
                    name="Красная кнопка",
                    description="Красная кнопка — просто для демонстрации.",
                    color="red",
                ),
            ]
            db.session.add_all(demo_buttons)

        db.session.commit()
        print("Справочники, админ и кнопки созданы.")
        # Тестовые кнопки
        if not Button.query.first():
            demo_buttons = [
                Button(
                    name="Синяя кнопка",
                    description="Это пример синей кнопки из базы данных.",
                    color="blue",
                ),
                Button(
                    name="Зелёная кнопка",
                    description="Эта зелёная кнопка тоже пришла из MySQL.",
                    color="green",
                ),
                Button(
                    name="Красная кнопка",
                    description="Красная кнопка — просто для демонстрации.",
                    color="red",
                ),
            ]
            db.session.add_all(demo_buttons)

    db.session.commit()
    print("Справочники и админ созданы.")


if __name__ == "__main__":
    app.run(debug=True)
'''